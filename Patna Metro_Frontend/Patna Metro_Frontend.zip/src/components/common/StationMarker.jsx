import PropTypes from 'prop-types';
import { FaMapMarkerAlt, FaExchangeAlt } from 'react-icons/fa';

const StationMarker = ({
  stationName,
  lineColor = '#3182CE',
  isInterchange = false,
  size = 'medium',
  className = ''
}) => {
  const sizeClasses = {
    small: 'w-6 h-6 text-xs',
    medium: 'w-8 h-8 text-sm',
    large: 'w-10 h-10 text-base'
  };

  return (
    <div className={`inline-flex items-center ${className}`}>
      <div
        className={`rounded-full flex items-center justify-center ${sizeClasses[size]}`}
        style={{ backgroundColor: isInterchange ? '#805AD5' : lineColor }}
      >
        {isInterchange ? (
          <FaExchangeAlt className="text-white" />
        ) : (
          <FaMapMarkerAlt className="text-white" />
        )}
      </div>
      {stationName && (
        <span className="ml-2 font-medium">
          {stationName}
          {isInterchange && (
            <span className="ml-1 text-xs text-gray-500">(Interchange)</span>
          )}
        </span>
      )}
    </div>
  );
};

StationMarker.propTypes = {
  stationName: PropTypes.string,
  lineColor: PropTypes.string,
  isInterchange: PropTypes.bool,
  size: PropTypes.oneOf(['small', 'medium', 'large']),
  className: PropTypes.string
};

export default StationMarker;